---
navigation:
  parent: crazyae2addons_index.md
  title: 疯狂计算工具
  icon: crazyae2addons:crazy_calculator
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:crazy_calculator
---

# 疯狂计算工具

<ItemImage id="crazyae2addons:crazy_calculator" scale="4"></ItemImage>

疯狂计算工具是一件便携工具，会打开GUI计算器。

## 使用方法

1. **手持使用**
    - 手持右击打开其GUI。

2. **输入表达式**
    - 可以使用加法、减法、乘法、除法、括号。例如：2k*(1/3m)+12g（2k为2000，3m为3 000 000，12g为12 000 000 000）

3. **计算结果**
    - 按下按钮，即会在下方给出计算结果。