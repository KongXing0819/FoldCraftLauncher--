---
navigation:
  parent: crazyae2addons_index.md
  title: 疯狂样板供应器
  icon: crazyae2addons:crazy_pattern_provider
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:crazy_pattern_provider
---

# 疯狂样板供应器

<BlockImage id="crazyae2addons:crazy_pattern_provider" scale="4"></BlockImage>

疯狂样板供应器是应用能源2（AE2）样板供应器的升级版，容量更大，且拥有可滚动的界面。

---

## 重要特性

- **81个样板槽**
   - 最多可存储81个经过编码的样板，相较之下标准供应器只有9个槽位。
   - GUI中可通过滚动条滚动查看各槽位。