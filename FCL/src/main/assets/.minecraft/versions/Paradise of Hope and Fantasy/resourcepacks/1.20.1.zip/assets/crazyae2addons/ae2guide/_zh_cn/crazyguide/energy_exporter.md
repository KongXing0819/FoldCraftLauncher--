---
navigation:
  parent: crazyae2addons_index.md
  title: 能源输出器
  icon: crazyae2addons:energy_exporter
categories:
  - Energy and Item Transfer
item_ids:
  - crazyae2addons:energy_exporter
---

# 能源输出器

能源输出器是一类线缆子部件，能让ME网络向其面对的机器和存储方块输出Forge能量（FE）或格雷科技能量（EU）。它会自动抽取网络中的能量向外部输出。

## 使用方法

1. **放置子部件**：将能源输出器放置在ME线缆上，面朝接受能量的方块。
2. **打开GUI**：右击子部件打开其设置界面。
3. **安装升级**：
    - **速度卡**：指数式增加能源传输率。
4. **格雷科技（GregTech）支持**：
    - 向槽位中放入电池可切换至格雷科技EU模式。
    - 输出的电压由电池等级决定，如低压（LV）、中压（MV）、高压（HV）等。
    - 必须使用锂电池。
5. **界面输出**：
    - 界面中会显示当前的传输率。
    - 在格雷科技模式下，还会显示电压和电流。

能源输出器会根据放入的电池和目标机器的功能自适应输出FE或EU。输出时此设备会遵守能量转换率，且不会使得网络耗能过量⸺网络中能量少于30%时便不会输出。